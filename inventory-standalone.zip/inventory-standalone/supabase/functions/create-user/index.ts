// Edge Function: create-user
// بيستخدمه الأدمن عشان يضيف مستخدم جديد (موظف مخزن أو أدمن تاني) من غير ما
// يفصله من جلسة الدخول بتاعته هو (مشكلة شائعة لو اتعمل الإنشاء من المتصفح مباشرة).
//
// انشره بالأمر: supabase functions deploy create-user

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "غير مصرح" }), { status: 401, headers: corsHeaders });
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    // تحقق من هوية مين اللي بيطلب، وإنه أدمن فعلاً
    const jwt = authHeader.replace("Bearer ", "");
    const { data: callerData, error: callerErr } = await admin.auth.getUser(jwt);
    if (callerErr || !callerData?.user) {
      return new Response(JSON.stringify({ error: "غير مصرح" }), { status: 401, headers: corsHeaders });
    }

    const { data: callerProfile } = await admin
      .from("profiles")
      .select("role")
      .eq("id", callerData.user.id)
      .single();

    if (!callerProfile || callerProfile.role !== "admin") {
      return new Response(JSON.stringify({ error: "هذا الإجراء متاح للمسؤولين فقط" }), { status: 403, headers: corsHeaders });
    }

    const { name, pin, role } = await req.json();
    if (!name || !pin || pin.length < 6) {
      return new Response(JSON.stringify({ error: "الاسم مطلوب والرقم السري لازم يكون 6 أرقام على الأقل" }), { status: 400, headers: corsHeaders });
    }

    const email = `u-${crypto.randomUUID()}@warehouse.local`;

    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password: pin,
      email_confirm: true,
    });
    if (createErr || !created?.user) {
      return new Response(JSON.stringify({ error: createErr?.message || "تعذر إنشاء المستخدم" }), { status: 400, headers: corsHeaders });
    }

    const { error: profileErr } = await admin.from("profiles").insert({
      id: created.user.id,
      name,
      email,
      role: role === "admin" ? "admin" : "staff",
    });
    if (profileErr) {
      // نظّف حساب auth اللي اتعمل لو فشل إدخال البروفايل
      await admin.auth.admin.deleteUser(created.user.id);
      return new Response(JSON.stringify({ error: profileErr.message }), { status: 400, headers: corsHeaders });
    }

    return new Response(JSON.stringify({ id: created.user.id, name, role }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: corsHeaders });
  }
});
